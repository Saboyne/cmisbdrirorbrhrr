Frequently asked questions and error documentation

# WebServer refused to connect

 1. Make sure that your server has the specified port open. You may need to whitelist it in your control panel or disable your active firewall. You can try the following commands:
    Please replace "PORT" with the given port in your config.json.
    ~ iptables -A INPUT -p udp --dport PORT -j ACCEPT
    ~ iptables -A INPUT -p tcp --dport PORT -j ACCEPT
    For CentOs:
    ~ systemctl stop firewalld.
 
 2. Make sure you are using the correct URL path with the given port, for example: 1.1.1.1:666 
    The port MUST be given otherwise it does not work.

# Current cons bug
 1. If you stopped screening the API Manager while a user had an attack in progress, it will be saved in the users.json file; to reset it, you must set "curCons" back to "0".
    To prevent such a thing from happening, make sure you have 0 running attacks while rechecking the API Manager.

If you still have questions please checkout t.me/VolityChat or dm @tcpall
 ~ @tcpall 1.22.2023 | volity-api.to