## VolityStress API Manager | v1.7

 - API Funnel Support
 - SSH Support
 - Raw Support
 - Telnet Support

## User Docs
"plan": the plan you want to give from plans.json to the selected user
"key": "the API key for the selected user
"curCons": displays his active cons, set it to 0 as default
"status":  active / banned to ban a user API key
"expire":  expirey as m/d/y

## Plan Docs
"time": max boot time
"threads": max threads usage
"pps": max pps usage
"maxCons": max cons usage

## Methods Docs
[HOST]    = Target
[PORT]    = Port
[TIME]    = Boot time
[PPS]     = PP/s
[THREADS] = Threads

"status":  online / offline to disable global attacks
"dclogs": true / false for webhook logs
"time":    Max boot time each method
"minatk":  Minimum attack time
"whitelist": true / false
(Allows only whitelisted ips to send an attack request)

PPS & Threads do not need to be defined in the Funnel

Blacklist targets
Blacklist entry domains with for example .gov / .edu
Valid IPv4 check

Error handler in ./Logs or console
Edit Discord Webhook logs in ./config.json

## API URLS
Methods:
List:    localhost:666/api/methods?username=[USER]&key=[KEY]

Specs:
Servers: localhost:666/api/specs!ssh?username=[USER]&key=[KEY]
Raw:     localhost:666/api/specs!raw?username=[USER]&key=[KEY]
APIs:    localhost:666/api/specs!apis?username=[USER]&key=[KEY]
Telnet:  localhost:666/api/specs!telnet?username=[USER]&key=[KEY]

Attack:
localhost:666/api/attack?username=[USER]&key=[KEY]&host=[TARGET]&port=[PORT]&time=[TIME]&method=[METHOD]&pps=[PPS]&threads=[THREADS]


## Install Setup

Prefered OS Debian Or Ubuntu

1. Setup
           Change the configs files in ./Configs
           
2. Screen the Manager
           apt install screen -y
           chmod 777 * && screen ./api

## Changelog
v1.7
 * User Management
 * Whitelist system
 * Min attack time fix
 * DC Logs settings
 * Better error handling
 * Added faq

v1.6 and lower
 * Added Telnet Support for Mirais
 * Added Raw Support for qbots
 * Added Whitelist function

 ~ @tcpall 2.7.2022 | volity-api.to