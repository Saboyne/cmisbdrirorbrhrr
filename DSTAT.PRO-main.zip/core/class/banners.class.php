<?php

class Banners {

	/* Login */
	public function BannerInfo($id) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `banners` WHERE `id` = :ID ORDER by `id` DESC LIMIT 1");
		$DataBase->Bind(':ID', $id);
		$DataBase->Execute();

		return $DataBase->Single();

	}

	/* Login */
	public function ChangeBanner($id, $name, $url, $expiring) {
		global $DataBase;

		$DataBase->Query("UPDATE `banners` SET `url`=:Url, `name`=:Name, `expiring`=:Expiring WHERE `id` = :ID");
		$DataBase->Bind(':ID', $id);
		$DataBase->Bind(':Url', $url);
		$DataBase->Bind(':Name', $name);
		$DataBase->Bind(':Expiring', $expiring);

		if (!$DataBase->Execute()) {
			return false;
		} else {
			return true;
		}

	}
	
	public function isExpired($id) {
		global $DataBase;

		$DataBase->Query("SELECT * FROM `banners` WHERE `id` = :ID ORDER by `id` DESC LIMIT 1");
		$DataBase->Bind(':ID', $id);
		$DataBase->Execute();

		$res = $DataBase->Single();

		if ($res['expiring'] < time()) {
			return true;
		} else {
			return false;
		}

	}
}