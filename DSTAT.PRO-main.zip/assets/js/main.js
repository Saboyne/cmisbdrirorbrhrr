/* register */
function Register() {
  // Create ajax form
  let formData = new FormData(document.getElementById("Register"));
  // Send ajax request
  $.ajax({
    url: "/process.php?Register",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        setTimeout(function () {
          location.href = "/login";
        }, 1000);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}
  

/* register */
function Login() {
  // Create ajax form
  let formData = new FormData(document.getElementById("Login"));
  // Send ajax request
  $.ajax({
    url: "/process.php?Login",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        setTimeout(function () {
          // location.href = "/login";
          location.reload();
        }, 1000);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}

function Copy(ip, what) {
  if (what == 1) {
    navigator.clipboard.writeText(ip);
    Notify('IP Address was copied!', 'success');
  } else {
    navigator.clipboard.writeText(ip);
    Notify('URL Address was copied!', 'success');
  }
}


function editProfile() {
  // Create ajax form
  let formData = new FormData(document.getElementById("editProfile"));
  // Send ajax request
  $.ajax({
    url: "/process.php?EditProfile",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        setTimeout(function () {
          // location.href = "/login";
          location.reload();
        }, 1000);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}


function ModifyUser() {
  // Create ajax form
  let formData = new FormData(document.getElementById("modifyuser"));
  // Send ajax request
  $.ajax({
    url: "/process.php?ModifyUser",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        setTimeout(function () {
          // location.href = "/login";
          location.reload();
        }, 1000);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}

function AddNews() {
  // Create ajax form
  let formData = new FormData(document.getElementById("addnews"));
  // Send ajax request
  $.ajax({
    url: "/process.php?AddNews",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        setTimeout(function () {
          // location.href = "/login";
          location.reload();
        }, 1000);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}

function ModifyMessage() {
  // Create ajax form
  let formData = new FormData(document.getElementById("modifymsg"));
  // Send ajax request
  $.ajax({
    url: "/process.php?ModifyMessage",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        setTimeout(function () {
          // location.href = "/login";
          location.reload();
        }, 1000);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}

function DeleteMessage() {
  // Create ajax form
  let formData = new FormData(document.getElementById("modifymsg"));
  // Send ajax request
  $.ajax({
    url: "/process.php?DeleteMessage",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        setTimeout(function () {
          // location.href = "/login";
          location.reload();
        }, 1000);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}

function Ping() {
  Notify('Processing your request...', 'info');
  // Create ajax form
  let formData = new FormData(document.getElementById("ping"));
  // Send ajax request
  $.ajax({
    url: "/tools.php?PingAddress",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        // setTimeout(function () {
        //   // location.href = "/login";
        //   location.reload();
        // }, 1000);
        $("#result").fadeIn();
        $("#hops").val(res[2]);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}

function GeoIP() {
  Notify('Processing your request...', 'info');
  // Create ajax form
  let formData = new FormData(document.getElementById("geoip"));
  // Send ajax request
  $.ajax({
    url: "/tools.php?GeoIP",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        // setTimeout(function () {
        //   // location.href = "/login";
        //   location.reload();
        // }, 1000);
        $("#result").fadeIn();
        $("#ipr").text(res[2]);
        $("#continent").text(res[3]);
        $("#country").text(res[4]+" ("+res[5]+")");
        $("#city").text(res[6]);
        // console.log(res[2]);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}

function Whois() {
  Notify('Processing your request...', 'info');
  // Create ajax form
  let formData = new FormData(document.getElementById("whois"));
  // Send ajax request
  $.ajax({
    url: "/tools.php?Whois",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        // setTimeout(function () {
        //   // location.href = "/login";
        //   location.reload();
        // }, 1000);
        $("#result").fadeIn();
        $("#rez").text(res[2]);
        // console.log(res[2]);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}



function PassGen() {
  Notify('Processing your request...', 'info');
  // Create ajax form
  let formData = new FormData(document.getElementById("passgen"));
  // Send ajax request
  $.ajax({
    url: "/tools.php?PassGen",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        // setTimeout(function () {
        //   // location.href = "/login";
        //   location.reload();
        // }, 1000);
        $("#resultdiv").fadeIn();
        $("#result").val(res[2]);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}

function HashGen() {
  Notify('Processing your request...', 'info');
  // Create ajax form
  let formData = new FormData(document.getElementById("hashgen"));
  // Send ajax request
  $.ajax({
    url: "/tools.php?HashGen",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        // setTimeout(function () {
        //   // location.href = "/login";
        //   location.reload();
        // }, 1000);
        $("#resultdiv").fadeIn();
        $("#result").val(res[2]);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}

function getStringBeforeChar() {
  Notify('Processing your request...', 'info');
  // Create ajax form
  let formData = new FormData(document.getElementById("stringbefore"));
  // Send ajax request
  $.ajax({
    url: "/tools.php?GetStringBefore",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        // setTimeout(function () {
        //   // location.href = "/login";
        //   location.reload();
        // }, 1000);
        $("#resultdiv").fadeIn();
        $("#result").val(res[2]);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}

function getStringAfterChar() {
  Notify('Processing your request...', 'info');
  // Create ajax form
  let formData = new FormData(document.getElementById("stringafter"));
  // Send ajax request
  $.ajax({
    url: "/tools.php?GetStringAfter",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        $("#resultdiv").fadeIn();
        $("#result").val(res[2]);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}


function delDuplicates() {
  Notify('Processing your request...', 'info');
  // Create ajax form
  let formData = new FormData(document.getElementById("deleteduplicates"));
  // Send ajax request
  $.ajax({
    url: "/tools.php?deleteDuplicateLines",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        // setTimeout(function () {
        //   // location.href = "/login";
        //   location.reload();
        // }, 1000);
        $("#resultdiv").fadeIn();
        $("#result").val(res[2]);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}

function ChangeBanner() {
  // Create ajax form
  let formData = new FormData(document.getElementById("changebanner"));
  // Send ajax request
  $.ajax({
    url: "/process.php?ChangeBanner",
    type: "POST",
    contentType: false,
    cache: false,
    processData: false,
    data: formData,
    success: function (r) {
      var res = JSON.parse(r);
      // Alert
      Notify(res[1], res[0]);

      if (res[0] == "success") {
        setTimeout(function () {
          // location.href = "/login";
          location.reload();
        }, 1000);
      }
      return false;
    },
    error: function (err) {
      return false;
    },
  });
}